#include <stdio.h>
#define MAX_h 100

void heap_sort(int arr[], int size);
void buildHeap(int arr[], int size);
int del_root(int arr[], int *size);
void restoreDown(int arr[], int i, int size );
void display_hs(int arr[], int n);

void heapsort()
{
    int i;
    int arr[MAX_h],n;
    printf("\t\t\t\t HEAP SORT \n");
    printf("Enter number of elements : ");
    scanf("%d",&n);

    for(i=1; i<=n; i++)
    {
        printf("Enter element %d : ",i);
        scanf("%d",&arr[i]);
    }

    printf("Entered list is :\n");
    display_hs(arr,n);

    heap_sort(arr,n);

    printf("Sorted list is :\n");
    display_hs(arr,n);
    printf("PRESS ANY BUTTON TO GO BACK");
    getch();
    return;
}/*End of main()*/

void heap_sort(int arr[], int size)
{
    int max_1;
    buildHeap(arr, size);
    printf("Heap is : ");
    display_hs(arr,size);

    while(size>1)
    {
        max_1 = del_root(arr,&size);
        arr[size+1]=MAX_h;
    }
}/*End of heap_sort*/

void buildHeap(int arr[], int size)
{
    int i;
    for(i=size/2; i>=1; i--)
        restoreDown(arr,i,size);
}/*End of buildHeap()*/

int del_root(int arr[], int *size)
{
    int max_1 = arr[1];
    arr[1] = arr[*size];
    (*size)--;
    restoreDown(arr,1,*size);
    return max_1;
}/*End of del_root()*/

void restoreDown(int arr[], int i, int size )
{
    int left=2*i, right=left+1;

    int num=arr[i];

    while(right<=size)
    {
        if( num>=arr[left] && num>=arr[right] )
        {
            arr[i] = num;
            return;
        }
        else if(arr[left] > arr[right])
        {
            arr[i] = arr[left];
            i = left;
        }
        else
        {
            arr[i] = arr[right];
            i = right;
        }
        left = 2 * i;
        right = left + 1;
    }

    if(left == size && num < arr[left] ) /*when right == size+1*/
    {
        arr[i]=arr[left];
        i = left;
    }
    arr[i]=num;
}/*End of restoreDown()*/

void display_hs(int arr[], int n)
{
    int i;
    for(i=1; i<=n; i++)
        printf("%d \t ",arr[i]);
    printf("\n");
}
