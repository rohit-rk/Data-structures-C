#include <stdio.h>
#include <stdlib.h>
#include<conio.h>
#include "arraySumViaPointers.h"
#include "AVL.h"
#include "binary search.h"
#include "binaryTree_array.h"
#include "BST.h"
#include "BST_threaded.h"
#include "bubble sort.h"
#include "circular linked list.h"
#include "circularQueue_array.h"
#include "circularQueue_list.h"
#include "dequeue.h"
#include "double linked list.h"
#include "expression tree.h"
#include "fibonacci search.h"
#include "heap sort.h"
#include "heap tree.h"
#include "insertion sort.h"
#include "linear search.h"
#include "merge sort.h"
#include "polish notation.h"
#include "queue_array.h"
#include "queue_list.h"
#include  "quick sort.h"
#include "selection sort.h"
#include "single linked list.h"
#include "sorting in files.h"
#include "stack_array.h"
#include "stack_list.h"
#include "stack-2_array-1.h"
#include "Vector.h"
#include "links.h"
#include "out.h"
void main()
{
    int i;
    int choice;
    system("cls");
    show();
    getout();
    getch();
    system("cls");
    show();
    while(choice)
    {
        printf("\nPROGRAMS:\n");
        printf("\t1.LINKED LISTS\n");
        printf("\t2.STACKS\n");
        printf("\t3.QUEUES\n");
        printf("\t4.SORTING\n");
        printf("\t5.SEARCHING\n");
        printf("\t6.TREES\n");
        printf("\t7.VECTORS\n");
        printf("\t8.Array Elements Sum\n");
        printf("\t9.Sorting File Data\n");
        printf("\t10.Exit\n");
        printf("Enter your choice:  ");
        scanf("%d",&choice);
        switch(choice)
        {
        case 1:
            programs_list();
            break;
        case 2:
            programs_stack();
            break;
        case 3:
            program_queue();
            break;
        case 4:
            program_sort();
            break;
        case 5:
            program_search();
            break;
        case 6:
            program_trees();
            break;
        case 7:
            vect();
            break;
        case 8:
            arraysum();
            break;
        case 9:
            sortfiles();
            break;
        case 10:
            system("cls");
            getout();
            exit(0);
            break;
        default:
            printf("\n\t Invalid choice\n");
        }
        system("pause");
        system("cls");
        main();
    }
}

