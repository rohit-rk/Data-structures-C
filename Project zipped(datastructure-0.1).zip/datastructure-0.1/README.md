
This is my DataStructure Project

You can install on your linux machine by typing following commands


1.  ./configure

2.  make

3.  sudo make install

